__author__ = 'George Kipp'
# Script:
# Created Date: 6/25/2015
# Last Modified Date: 6/25/2015
# Description:

# Modules: arcpy, os, math

# Global Variables:


# Local Variables: none

# Iteration Variables: field

# Input Parameters: input_point, coord_sys

# Output:

# Computation:

# import modules
import arcpy, os

# okay to overwrite output
arcpy.env.overwriteOutput = True

# inputs
#input_point = arcpy.GetParameterAsText(0)
input_point = r"E:\Work\MDC\GISData\MOTools\New_Shapefile.shp"
#coord_sys = arcpy.GetParameterAsText(1)
coord_sys = arcpy.Describe(input_point).spatialReference

# get workspace from input line
workspace = os.path.dirname(input_point)
print workspace

def gdb_check():
    suffix = os.path.dirname(input_point)
    if suffix.endswith(".gdb") or suffix.endswith(".mdb"):
        extension = ""
    else:
        extension = ".shp"
    return extension

try:
    # x coordinate
    for field in arcpy.ListFields(input_point):
        if field == "EASTING":
            easting_field = "ESTING"
        else:
            easting_field = "EASTING"
    arcpy.AddField_management(input_point, easting_field, "Double",)
    easting_expression = "float(!shape.firstpoint.x!)" # expression used for calculating UTM X coordinate
    arcpy.CalculateField_management(input_point, easting_field, easting_expression, "PYTHON_9.3")

    # y coordinate
    for field in arcpy.ListFields(input_point):
        if field == "NORTH":
            northing_field = "NRTH"
        else:
            northing_field = "NORTH"
    arcpy.AddField_management(input_point, northing_field, "Double",)
    northing_expression = "float(!shape.firstpoint.y!)" # expression used for calculating UTM X coordinate
    arcpy.CalculateField_management(input_point, northing_field, northing_expression, "PYTHON_9.3")

    arcpy.AddMessage("Successfully calculated UTM coordinates.")
except:
    arcpy.AddError("Error calculating UTM coordinates.")

try:
    # create copy of input points
    copy_name = workspace + "\point_copy" + gdb_check()
    print copy_name
    copy_point = arcpy.CopyFeatures_management(input_point, copy_name)
    # convert copied point feature class to WGS84
    spatial_ref = arcpy.Describe(input_point).spatialReference
    if spatial_ref == 7030 or spatial_ref == 10737:
        pass
    else:
        spatial_ref_copy = arcpy.SpatialReference(7030)
        arcpy.DefineProjection_management(copy_point, spatial_ref_copy)

    # latitude
    # create latitude field in input point
    for field in arcpy.ListFields(input_point):
        if field == "LATITUDE":
            lat_field = "LAT"
        else:
            easting_field = "LATITUDE"
    arcpy.AddField_management(input_point, lat_field, "Double",)

    # create latitude field in copied point
    for field in arcpy.ListFields(copy_point):
        if field == "LATITUDE":
            lat_field = "LAT"
        else:
            lat_field = "LATITUDE"
    arcpy.AddField_management(copy_point, lat_field, "Double",)
    lat_expression = "float(!shape.firstpoint.y!)" # expression used for calculating latitude
    arcpy.CalculateField_management(copy_point, lat_expression, lat_expression, "PYTHON_9.3")

    # longitude
    # create longitude field in input point
     for field in arcpy.ListFields(input_point):
        if field == "LONGITUDE":
            longitude_field = "LONGI"
        else:
            longitude_field = "LONGITUDE"
    arcpy.AddField_management(input_point, longitude_field, "Double",)

    # create longitude field in copied point
    for field in arcpy.ListFields(copy_point):
        if field == "LONGITUDE":
            longitude_field = "LONGI"
        else:
            longitude_field = "LONGITUDE"
    arcpy.AddField_management(copy_point, longitude_field, "Double",)
    longitude_expression = "float(!shape.firstpoint.x!)" # expression used for calculating UTM X coordinate
    arcpy.CalculateField_management(copy_point, longitude_field, longitude_expression, "PYTHON_9.3")

    # search cursor to get lat/long values
    with arcpy.da.Sear

    # insert cursor writes values from copied point to original point
    with arcpy.da.UpdateCursor(input_point, [lat_field, longitude_field]) as upCursor:
        for row in upCursor:
            row.setValue()
    del copy_point
except:
    arcpy.AddError("Error calculating Lat/Long.")